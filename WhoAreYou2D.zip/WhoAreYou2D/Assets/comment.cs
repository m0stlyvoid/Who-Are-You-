using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;


public class comment : MonoBehaviour
{
    [SerializeField] List<string> redComments;
    private TextMeshProUGUI text;
    [SerializeField] List<string> greenComments;
    [SerializeField] List<string> blueComments;
  
    textRed TextRed;
    [SerializeField] GameObject red;
    TextGreen textGreen;
    [SerializeField] GameObject green;
    textBlue TextBlue;
    [SerializeField] GameObject blue;

    Kugel movement;
    [SerializeField] GameObject kugel;



    void Awake()
    {
        TextRed = red.GetComponent<textRed>();
        textGreen = green.GetComponent<TextGreen>();
        TextBlue = blue.GetComponent<textBlue>();
        movement = kugel.GetComponent<Kugel>();
    }

    // Start is called before the first frame update
    void Start()
    {
        text = gameObject.GetComponent<TextMeshProUGUI>();

        if (movement.hitRed)
        {
            text.text = redComments[TextRed.numberRed];
        }
        
        if (movement.hitBlue)
        {
            text.text = blueComments[TextBlue.numberBlue];
        }   

        if(movement.hitGreen)
        {
            text.text = greenComments[textGreen.numberGreen];
        }
            
       
      
        Debug.Log(TextRed.numberRed);
    }
    
}
