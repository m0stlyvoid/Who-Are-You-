using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;


public class Kugel : MonoBehaviour
{
    private Rigidbody2D rb;
    [SerializeField] private float positioningState;
    public bool canShoot;
    public bool green;
    public bool red;
    public bool blue;
   

   

    [SerializeField] private float shootForce;
    [SerializeField] private float gravity;
    [SerializeField] private float rotionSpeed;
    [SerializeField] private float moveSpeed;
    [SerializeField] private float bubbleNumber;
    [SerializeField] private GameObject rotationMarker;
    [SerializeField] private GameObject end;

    [SerializeField] private GameObject redButtonObj;
    [SerializeField] private GameObject blueButtonObj;
    [SerializeField] private GameObject greenButtonObj;
    GameObject[] turnOff;
    GameObject[] turnOff2;
    GameObject[] turnOff3;
    GameObject[] turnOffFinal;

    public bool hitRed;
    public bool hitGreen;
    public bool hitBlue;

    [SerializeField] GameObject kommentar;







    // Start is called before the first frame update
    void Start()
    {
        rb = gameObject.GetComponent<Rigidbody2D>();
        positioningState = 0;
        
    }

    // Update is called once per frame
    void Update()
    {
        //postioningste 0 -> set position
        //positioningstate 1 -> set rotatin
        // positioningstate 2 -> shoot
        //if (Input.GetKey("space") & canShoot & positioningState)


        if (Input.GetKey("space") && canShoot && positioningState == 3)
        {
            ballShot();
        }

        if (Input.GetKeyDown("space") && canShoot && positioningState < 3)
        {
            positioningState = positioningState + 1;

        }

        if (Input.GetKeyDown("space") & kommentar.activeInHierarchy)
        {
            kommentar.SetActive(false);
            SceneManager.LoadScene(0);

        }


        if (canShoot && positioningState == 0)
        {
            move();
        }

        if (Input.GetKey("a") && positioningState == 1)
        {
            rotateLeft();

        }

        if (Input.GetKey("d") && positioningState == 1)
        {
            rotateRight();
        }

        if (bubbleNumber == 0)
        {
            done();
            //sprite.texture = othersprite;
        }

        if(green | blue |red)
        {
            redButtonObj.SetActive(false);
            blueButtonObj.SetActive(false);
            greenButtonObj.SetActive(false);

        }    

        
        //.Log(rb.velocity.magnitude);

    }

    void ballShot()
    {
        Debug.Log("shoot");
        rb.AddForce(transform.up * shootForce);
        canShoot = false;
       // rb.gravityScale = gravity;
        rotationMarker.SetActive(false);
     
    }

    void rotateLeft()
    {
        transform.Rotate(0, 0, rotionSpeed);
        rb.constraints = RigidbodyConstraints2D.None;

    }

    void rotateRight()
    {
        transform.Rotate(0, 0, rotionSpeed * -1);
        rb.constraints = RigidbodyConstraints2D.None;
    }

    void move()
    {
        rb.velocity = new Vector2(Input.GetAxisRaw("Horizontal") * moveSpeed, rb.velocity.y);
    }


    void OnTriggerEnter2D(Collider2D collider)
    {
        Debug.Log(collider.gameObject.tag);

        if (collider.gameObject.tag == "green" & green || collider.gameObject.tag == "red" & red || collider.gameObject.tag == "blue" & blue)
        {
            Destroy(collider.gameObject);
            Debug.Log("hit bubble");
            bubbleNumber = bubbleNumber - 1;
            kommentar.SetActive(true);
            //transform.SetPositionAndRotation(-2.846451f, 2.678611f, 0);
            rb.velocity = new Vector2(0.0f, 0.0f);
            rb.constraints = RigidbodyConstraints2D.FreezePosition;
            redButtonObj.SetActive(true);
            blueButtonObj.SetActive(true);
            greenButtonObj.SetActive(true);
            
            positioningState = 1;
            

            if (collider.gameObject.tag == "green" & green)
            {
                hitGreen = true;
                
                
            }

            else if (collider.gameObject.tag == "red" & red)
            {
                hitRed = true;
               
            }

            else
            {
                hitBlue = true;
               
            }
            Debug.Log( hitBlue & hitGreen & hitRed );

            green = false;
            blue = false;
            red = false;
        }

    }

    public void GreenButton()
    {
        green = true;
        blue = false;
        red = false;
       
    }

    public void BlueButton()
    {
        green = false;
        blue = true;
        red = false;
     
    }

    public void RedButton()
    {
        green = false;
        blue = false;
        red = true;
     
    }

    void done()

    {
        end.SetActive(true);

        turnOff = GameObject.FindGameObjectsWithTag("green");
        foreach (GameObject obj in turnOff)
        {
            obj.SetActive(false);
        }
        turnOff2 = GameObject.FindGameObjectsWithTag("red");
        foreach (GameObject obj2 in turnOff2)
        {
            obj2.SetActive(false);
        }
        turnOff3 = GameObject.FindGameObjectsWithTag("blue");
        foreach (GameObject obj3 in turnOff3)
        {
            obj3.SetActive(false);
        }


    }

    public void activateShooting()
    {
        canShoot = true;
    }

}
